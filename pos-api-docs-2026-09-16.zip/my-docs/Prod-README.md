# Production deployment on an Ubuntu server

*Step-by-step instructions for building the SalesPlay / Vendrex / Sellmo documentation sites on an Ubuntu server and serving them on their public domains. Written for someone who has never deployed this project before. Every command is meant to be copied as-is.*

For day-to-day editing on a laptop see `README.md`. For how the brand system works see `TENANT_GUIDE.md`.

---

## Table of contents

1. [What you are deploying](#1-what-you-are-deploying)
2. [Server requirements](#2-server-requirements)
3. [One-time server setup](#3-one-time-server-setup)
4. [Get the code and configure the brands](#4-get-the-code-and-configure-the-brands)
5. [Build the three sites](#5-build-the-three-sites)
6. [Check the builds before publishing](#6-check-the-builds-before-publishing)
7. [Serve the sites with Nginx](#7-serve-the-sites-with-nginx)
8. [HTTPS certificates](#8-https-certificates)
9. [Updating the sites (every future release)](#9-updating-the-sites-every-future-release)
10. [One-command deploy script](#10-one-command-deploy-script)
11. [Rollback](#11-rollback)
12. [Troubleshooting](#12-troubleshooting)
13. [Security notes](#13-security-notes)
14. [Checklist](#14-checklist)

---

## 1. What you are deploying

The project is a **static website**: after a build there is no server-side code, no database and no Node process to keep running. The build produces plain HTML/CSS/JS files that any web server can serve.

One source tree produces **three sites** — one per brand — each into its own folder:

| Brand | Build command | Output folder | Public domain |
|---|---|---|---|
| SalesPlay | `npm run build` | `build/salesplay/` | `developer.salesplay.com` |
| Vendrex | `npm run build:vendrex` | `build/vendrex/` | `developer.vendrex.com` |
| Sellmo | `npm run build:sellmo` | `build/selmo/` | `developer.backofficewebportal.com` |

The build itself needs Node.js and Python. Serving the result needs only Nginx (or any web server). Both can live on the same machine, which is what this guide sets up.

**Never run `npm start` on the production server.** That is the development server — slow, unminified, and it shows placeholder dates and no search. Production always means `npm run build…` followed by Nginx serving the output.

---

## 2. Server requirements

| Item | Minimum | Notes |
|---|---|---|
| Ubuntu | 22.04 LTS or 24.04 LTS | commands below are tested on both |
| RAM | 2 GB (4 GB recommended) | the Node build of one brand peaks around 1.5 GB; see §12 if it runs out |
| Disk | 2 GB free | `node_modules` ≈ 700 MB, three builds ≈ 150 MB |
| CPU | 1 core | a build takes 1–3 minutes per brand |
| Network | outbound HTTPS | to fetch packages; the build does **not** call the SalesPlay API |
| DNS | A/AAAA records | each public domain must point at this server before §8 (certificates) |
| Access | a user with `sudo` | do not build or deploy as `root` |

---

## 3. One-time server setup

Run everything in this section once, as your normal user (with `sudo` where shown).

### 3.1 System packages

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y git curl build-essential nginx python3 python3-pip python-is-python3
```

- `python-is-python3` matters: the build runs the command **`python`** (not `python3`) from `docusaurus.config.js`. On Ubuntu that command does not exist unless this package is installed.
- `nginx` is the web server that will serve the built files.

### 3.2 Python library

```bash
sudo apt install -y python3-yaml
python -c "import yaml; print('PyYAML OK')"
```

(If your Ubuntu refuses `pip install` system-wide, `python3-yaml` from apt is the right way. The scripts need only PyYAML.)

### 3.3 Node.js 22

Node **22 LTS** is required — the brand loader uses `process.loadEnvFile`, which does not exist in older Node. Install from NodeSource (the Ubuntu default `nodejs` package is too old):

```bash
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash -
sudo apt install -y nodejs
node --version    # must print v22.x
npm --version
```

### 3.4 A place for the code

```bash
sudo mkdir -p /var/www
sudo chown "$USER":"$USER" /var/www
```

---

## 4. Get the code and configure the brands

### 4.1 Clone

```bash
cd /var/www
git clone https://github.com/JanaBan99/POS-API-Documentation.git docs
cd /var/www/docs
npm ci
```

`npm ci` installs the exact dependency versions from `package-lock.json` (use it on servers instead of `npm install`).

### 4.2 Brand configuration files (required)

Each brand's facts live in a small text file `.env.<brand>` at the project root. **They are not in the repository** (git-ignored), so a fresh clone has none. Create all three:

```bash
cp .env.example .env.salesplay
cp .env.example .env.vendrex
cp .env.example .env.sellmo
```

`.env.salesplay` is correct as copied. Edit the other two — every line is required:

```bash
nano .env.vendrex
```
```
TENANT=vendrex
TENANT_NAME=Vendrex
TENANT_HOST=vendrex.com
TENANT_API_BASE_URL=https://api.vendrex.com/v1.0
TENANT_BACKOFFICE_URL=https://platform.vendrex.com/
TENANT_DEVELOPER_URL=https://developer.vendrex.com
TENANT_SITE_TITLE=Vendrex Documentation
TENANT_POSTMAN_URL=https://developer.vendrex.com/download_postman_collection.php
TENANT_FAVICON=favicon.png
TENANT_IMG_DIR=vendrex
```

```bash
nano .env.sellmo
```
```
TENANT=sellmo
TENANT_NAME=Sellmo
TENANT_HOST=sellmopos.com
TENANT_API_BASE_URL=https://api.backofficewebportal.com/v1.0
TENANT_BACKOFFICE_URL=https://sellmo.backofficewebportal.com/
TENANT_DEVELOPER_URL=https://developer.backofficewebportal.com
TENANT_SITE_TITLE=Sellmo Documentation
TENANT_POSTMAN_URL=https://developer.backofficewebportal.com/download_postman_collection.php
TENANT_FAVICON=favicon.png
TENANT_IMG_DIR=selmo
```

Notes:
- Sellmo's image folder is spelled **`selmo`** (that is the real folder name under `static/img/`), while the brand key is `sellmo`.
- These files hold only public URLs and names. **Never put a password or API token in them.**
- If a value is missing the build stops immediately with `TENANT_… is missing — check .env.<brand>`.

Lock the files down anyway:

```bash
chmod 600 .env.*
```

---

## 5. Build the three sites

From `/var/www/docs`:

```bash
npm run build            # SalesPlay  → build/salesplay/
npm run build:vendrex    # Vendrex    → build/vendrex/
npm run build:sellmo     # Sellmo     → build/selmo/
```

Each command:
1. loads that brand's `.env` file,
2. runs `python convert_spec.py` to write the brand's `static/api_spec.json`,
3. compiles every page, replacing "SalesPlay" text, URLs, logo, favicon and screenshots with the brand's,
4. builds the search index,
5. writes the finished site into `build/<brand>/`.

A successful build ends with:

```
[SUCCESS] Generated static files in "build/<brand>".
```

Two warnings are normal and can be ignored: the `onBrokenMarkdownLinks` deprecation notice, and the Docusaurus "update available" banner.

Builds are independent: each brand uses its own generated-files folder, so building one never overwrites another. You can build all three in one line:

```bash
npm run build && npm run build:vendrex && npm run build:sellmo
```

---

## 6. Check the builds before publishing

```bash
npm run check
```

This runs `tools/gio_check.py` against all three output folders and prints **one line per problem**, failing if:

- any file in a brand's output mentions another brand's name or domain (a "brand leak"),
- a machine-readable file (`llms.txt`, `sitemap.xml`, `api_spec.json`…) is missing,
- a link inside `llms.txt` points nowhere,
- a page has no `description`, more than one `<h1>`, or an emoji heading.

Only publish when it prints no problems. To check one brand: `npm run check:vendrex`.

Optional manual spot check of one brand on the server itself (temporary, port 3003):

```bash
npx docusaurus serve --dir build/vendrex --port 3003 --no-open
# open http://<server-ip>:3003 in a browser, then Ctrl+C
```

---

## 7. Serve the sites with Nginx

Nginx serves each brand's folder on its own domain. The build output is copied to a **release folder** that Nginx points at, so a failed build can never take a live site down (the copy happens only after `npm run check` passes).

### 7.1 Release folders

```bash
sudo mkdir -p /var/www/sites/salesplay /var/www/sites/vendrex /var/www/sites/selmo
sudo chown -R "$USER":www-data /var/www/sites
```

### 7.2 Copy the builds

```bash
rsync -a --delete build/salesplay/ /var/www/sites/salesplay/
rsync -a --delete build/vendrex/   /var/www/sites/vendrex/
rsync -a --delete build/selmo/     /var/www/sites/selmo/
```

(`rsync --delete` makes the release folder an exact mirror of the build, removing files from old releases.)

### 7.3 One Nginx site file per brand

Create `/etc/nginx/sites-available/developer.salesplay.com`:

```bash
sudo nano /etc/nginx/sites-available/developer.salesplay.com
```
```nginx
server {
    listen 80;
    listen [::]:80;
    server_name developer.salesplay.com;

    root /var/www/sites/salesplay;
    index index.html;

    # Docusaurus writes each page as <path>/index.html
    location / {
        try_files $uri $uri/ $uri.html /404.html;
    }

    # Long cache for fingerprinted assets, none for HTML
    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    location ~* \.html$ {
        add_header Cache-Control "no-cache";
    }

    gzip on;
    gzip_types text/plain text/css application/javascript application/json image/svg+xml;

    access_log /var/log/nginx/developer.salesplay.com.access.log;
    error_log  /var/log/nginx/developer.salesplay.com.error.log;
}
```

Repeat for the other two, changing only `server_name` and `root`:

| File | `server_name` | `root` |
|---|---|---|
| `/etc/nginx/sites-available/developer.vendrex.com` | `developer.vendrex.com` | `/var/www/sites/vendrex` |
| `/etc/nginx/sites-available/developer.backofficewebportal.com` | `developer.backofficewebportal.com` | `/var/www/sites/selmo` |

Enable them and reload:

```bash
sudo ln -s /etc/nginx/sites-available/developer.salesplay.com /etc/nginx/sites-enabled/
sudo ln -s /etc/nginx/sites-available/developer.vendrex.com /etc/nginx/sites-enabled/
sudo ln -s /etc/nginx/sites-available/developer.backofficewebportal.com /etc/nginx/sites-enabled/
sudo rm -f /etc/nginx/sites-enabled/default
sudo nginx -t          # must say "syntax is ok" and "test is successful"
sudo systemctl reload nginx
```

Test from the server before DNS is live:

```bash
curl -s -H "Host: developer.vendrex.com" http://localhost/ | grep -o "<title>[^<]*"
# → <title>Vendrex Documentation
```

---

## 8. HTTPS certificates

Once the three domains resolve to this server (check with `dig +short developer.salesplay.com`):

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d developer.salesplay.com -d developer.vendrex.com -d developer.backofficewebportal.com
```

Certbot edits the three Nginx files to add `listen 443 ssl`, the certificate paths and an HTTP→HTTPS redirect, and installs a timer that renews automatically. Verify renewal works:

```bash
sudo certbot renew --dry-run
```

---

## 9. Updating the sites (every future release)

Whenever the documentation changes (new commit on `main`):

```bash
cd /var/www/docs
git pull --ff-only
npm ci                                   # only needed if package-lock.json changed; harmless otherwise
npm run build && npm run build:vendrex && npm run build:sellmo
npm run check                            # stop here if it reports problems
rsync -a --delete build/salesplay/ /var/www/sites/salesplay/
rsync -a --delete build/vendrex/   /var/www/sites/vendrex/
rsync -a --delete build/selmo/     /var/www/sites/selmo/
```

No Nginx reload is needed — it serves whatever is in the release folders. The `.env.*` files are untouched by `git pull` (they are ignored), so they survive updates.

If `api_spec.yaml` changed, the endpoint pages are already regenerated in the repository; you do **not** need to run `gen_api_docs.py` on the server.

---

## 10. One-command deploy script

Save this as `/var/www/docs/deploy.sh` (it is not part of the repository; keep it on the server):

```bash
#!/usr/bin/env bash
# Build all three brands, run the checks, and publish only if they pass.
set -euo pipefail

REPO=/var/www/docs
SITES=/var/www/sites
cd "$REPO"

echo "== pulling"
git pull --ff-only
npm ci --silent

echo "== building"
npm run build
npm run build:vendrex
npm run build:sellmo

echo "== checking"
npm run check          # exits non-zero on any problem → script stops here, nothing published

echo "== publishing"
rsync -a --delete build/salesplay/ "$SITES/salesplay/"
rsync -a --delete build/vendrex/   "$SITES/vendrex/"
rsync -a --delete build/selmo/     "$SITES/selmo/"

echo "== done $(date -Is)"
```

```bash
chmod +x /var/www/docs/deploy.sh
/var/www/docs/deploy.sh
```

Because of `set -e`, the script stops at the first failure — a broken build or a failed check never reaches the `rsync` lines, so the live sites keep the previous release.

**Optional — automatic nightly deploy** (only if the team is comfortable with unreviewed commits going live):

```bash
crontab -e
# add:
30 2 * * * /var/www/docs/deploy.sh >> /var/log/docs-deploy.log 2>&1
```

---

## 11. Rollback

The release folders always hold the last *good* build. To go back one release:

```bash
cd /var/www/docs
git log --oneline -5                 # find the previous commit
git checkout <previous-commit>
npm run build && npm run build:vendrex && npm run build:sellmo && npm run check
rsync -a --delete build/salesplay/ /var/www/sites/salesplay/
rsync -a --delete build/vendrex/   /var/www/sites/vendrex/
rsync -a --delete build/selmo/     /var/www/sites/selmo/
git checkout main                    # return to main for the next deploy
```

For an instant rollback without rebuilding, keep a copy before each publish (add to `deploy.sh` before the `rsync` lines): `cp -a "$SITES" "$SITES.prev"` — then restore with `rsync -a --delete /var/www/sites.prev/ /var/www/sites/`.

---

## 12. Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `python: command not found` during build | Ubuntu has only `python3` | `sudo apt install python-is-python3` |
| `ModuleNotFoundError: No module named 'yaml'` | PyYAML missing | `sudo apt install python3-yaml` |
| `TENANT_… is missing — check .env.<brand>` | brand file absent or a line missing | §4.2 — every line is required |
| `process.loadEnvFile is not a function` | Node older than 20.12 | install Node 22 (§3.3) |
| Build killed / `JavaScript heap out of memory` | not enough RAM | `export NODE_OPTIONS=--max-old-space-size=3072` before building, or add swap: `sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile` |
| `npm run check` → "mentions another brand" | a page has a sister brand's name typed in the source | fix the page in the repository (write it as SalesPlay); do not publish |
| Vendrex site shows SalesPlay text or logo | published the wrong folder, or stale release | confirm `root` in the Nginx file matches the brand; re-run `rsync` for that brand |
| Nginx `403 Forbidden` | permissions on `/var/www/sites` | `sudo chown -R $USER:www-data /var/www/sites && sudo chmod -R 755 /var/www/sites` |
| Page loads but sub-pages give `404` | `try_files` line missing | use the `location /` block from §7.3 exactly |
| Search box says "index only available after build" | you are looking at `npm start`, not a build | never use `npm start` in production |
| `certbot` fails with a DNS / challenge error | domain not pointing at this server yet | fix DNS first, then re-run §8 |
| Build output says `Panic occurred at runtime` (rspack) | corrupted cache | `npx docusaurus clear && rm -rf .docusaurus-build*` then rebuild |

Build logs: everything a build prints is on your terminal; when run from cron it goes to `/var/log/docs-deploy.log`. Nginx logs: `/var/log/nginx/<domain>.error.log`.

---

## 13. Security notes

- The sites are static; there is nothing to attack server-side beyond Nginx itself. Keep Ubuntu and Nginx patched (`sudo apt upgrade`).
- Open only ports 22, 80 and 443: `sudo ufw allow OpenSSH && sudo ufw allow 'Nginx Full' && sudo ufw enable`.
- `.env.*` files contain no secrets by design. If any script ever needs an API token (e.g. the endpoint checker), pass it as a shell variable for that one command — never write it into a file in the repository.
- Do not build or run Nginx as `root`; the steps above use your user for building and `www-data` for serving.
- The test-account credentials used while writing the docs must never be on this server.

---

## 14. Checklist

**First deployment**
- [ ] Ubuntu updated; `git curl nginx python3 python3-yaml python-is-python3` installed
- [ ] Node 22 installed (`node --version` → v22)
- [ ] Repository cloned to `/var/www/docs`; `npm ci` done
- [ ] `.env.salesplay`, `.env.vendrex`, `.env.sellmo` created and filled; `chmod 600`
- [ ] Three builds succeed; `npm run check` reports nothing
- [ ] Release folders created; builds copied with `rsync`
- [ ] Three Nginx site files enabled; `nginx -t` OK; `curl -H "Host: …"` shows the right title for each
- [ ] DNS points at the server; `certbot` issued certificates; `certbot renew --dry-run` OK
- [ ] `deploy.sh` saved and executable
- [ ] Firewall enabled (22, 80, 443)

**Every update**
- [ ] `./deploy.sh` (or the §9 commands) — finishes with `== done`
- [ ] Open each of the three sites in a browser: correct logo, colour, title, and a search that returns results
